#include "ArRobot.h"
#include "PetBotMode.h"

void 
PetBotMode::TurnAround(ArRobot robot){
    robot.setDeltaHeading(180); // Adjust the angle as needed
    ArUtil::sleep(2550); // Turn for 2 seconds
    robot.setDeltaHeading(180);
    ArUtil::sleep(2550);
}
void 
PetBotMode::Stop(ArRobot robot){
    robot.stop();
}
void 
PetBotMode::Tracking(ArRobot robot, double ownerPos, double ownerAngle){
    double dis = _sd_Pos_PID(ownerPos);
    double ang = _sd_Angle_PID(ownerAngle);
    robot.move(dis);
    robot.setDeltaHeading(ang);
}
void 
PetBotMode::PlayGround(ArRobot robot){

}
void 
PetBotMode::Happy(ArRobot robot){
    robot.setDeltaHeading(45); // Adjust the angle as needed
    ArUtil::sleep(2000); // Turn for 2 seconds
    robot.setDeltaHeading(-90);
    ArUtil::sleep(2000);
    robot.setDeltaHeading(45);
}

double
PetBotMode::_sd_Pos_PID(double dPos){
    static double _sdPos_err;
    static double _sdDelta_err;
    static double _sdIntegral_err;
    static double _sdPrev_err;
    static long _slOutput_temp;
    _sdPos_err = PID_constants::POS_Desired - dPos;
	_sdDelta_err = _sdPos_err - _sdPrev_err;
	_sdIntegral_err += _sdPos_err;

	_slOutput_temp = _sdPos_err*PID_constants::POS_KP + 
					_sdIntegral_err*PID_constants::POS_KI + 
                    _sdDelta_err*PID_constants::POS_KD;
	_sdPrev_err = _sdPos_err ;

    //Make sure the output wont be too big in each calculation
    _slOutput_temp = _slOutput_temp >> 8;
    if((_slOutput_temp >> 8) > 100) _slOutput_temp = 100;
    return _slOutput_temp >> 8;
}
double 
PetBotMode::_sd_Angle_PID(double dAng){
    static double _sdAng_err;
    static double _sdDelta_err;
    static double _sdIntegral_err;
    static double _sdPrev_err;
    static long _slOutput_temp;
    _sdAng_err = PID_constants::ANG_Desired - dAng;
	_sdDelta_err = _sdAng_err - _sdPrev_err;
	_sdIntegral_err += _sdAng_err;

	_slOutput_temp = _sdAng_err*PID_constants::ANG_KP + 
					_sdIntegral_err*PID_constants::ANG_KI + 
                    _sdDelta_err*PID_constants::ANG_KD;
	_sdPrev_err = _sdAng_err ;

    //Make sure the output wont be too big in each calculation
    _slOutput_temp = _slOutput_temp >> 8;
    if((_slOutput_temp >> 8) > 30) _slOutput_temp = 30;
    return _slOutput_temp >> 8;
    return _slOutput_temp;
}
void 
PetBotMode::TestFunction(ArRobot robot){
  robot.move(100); // Adjust the velocity as needed
  ArUtil::sleep(2000); // Move for 2 seconds
    // Turn the robot left
  robot.setDeltaHeading(45); // Adjust the angle as needed
  ArUtil::sleep(1900);
  robot.setDeltaHeading(-45);
  ArUtil::sleep(1900);
  robot.setDeltaHeading(180);
  ArUtil::sleep(2550); // Turn for 2 seconds
  robot.setDeltaHeading(180);
  ArUtil::sleep(7000); // Turn for 2 seconds
}
