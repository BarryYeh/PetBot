#ifndef PETBOTMODE_H
#define PETBOTMODE_H

# include "ArRobot.h"

class PetBotMode
{
    public :
        void TurnAround(ArRobot robot, int last_task);
	void TurnAround(ArRobot robot);
        void Stop(ArRobot robot);
        void Tracking(ArRobot robot, double ownerPos, double ownerAngle);
        void PlayGround(ArRobot robot);
        void Happy(ArRobot robot);
        void Home(ArRobot robot);
        void TestFunction(ArRobot robot);
        //double test_vel(ArRobot *robot){return robot->getVel();};
    private :
        static double _sd_Pos_PID(double Pos);
        static double _sd_Angle_PID(double Ang);
        enum PID_constants{
            POS_KD = 1,
            POS_KI = 1,
            POS_KP = 1,
            POS_Desired = 1500,
            ANG_KD = 1,
            ANG_KI = 1,
            ANG_KP = 1,
            ANG_Desired =0
        };
};
#endif
